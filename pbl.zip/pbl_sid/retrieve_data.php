<?php
    $connection=mysqli_connect('localhost','root','','wallet');
    $g_p="SELECT * FROM `final amount`";
    $query=mysqli_query($connection,$g_p);
    $rows=mysqli_num_rows($query);
    if($rows>0){
        $get_parameter="SELECT * FROM `final amount` ORDER BY `Id` DESC LIMIT 1";
        $result=mysqli_query($connection,$get_parameter);
        $final=mysqli_fetch_assoc($result);
        echo $final['Amount_final'];
    }
    else{
        echo 0;
    }
    
?>