<?php
    $connection=mysqli_connect('localhost','root','','wallet');
    $amount=$_POST['amount'];
    $get_parameter="SELECT * FROM `final amount` ORDER BY `Id` DESC LIMIT 1";
    $result=mysqli_query($connection,$get_parameter);
    $final=mysqli_fetch_assoc($result);
    if($amount>$final['Amount_final']){
        //display an error message and go back
        header("Location: ../pbl_sid/abc.php");
    }
    else{
        $purpose=$_POST['purpose'];
        $insert_parameter="INSERT INTO `log_details` (`Sr.no`,`Amount`, `Purpose`, `Date_time`) VALUES (NULL,'$amount', '$purpose', CURRENT_TIME())";
        $insert_query=mysqli_query($connection,$insert_parameter);
        
        
        //substracting money from the wallet and updating
        $final=$final['Amount_final']-$amount;
        $insert_para="INSERT INTO `final amount` (`Id`, `Amount_final`) VALUES (NULL, '$final')";
        $inset_q=mysqli_query($connection,$insert_para);
        header("Location: ../pbl_sid/abc.php");
    }
?>