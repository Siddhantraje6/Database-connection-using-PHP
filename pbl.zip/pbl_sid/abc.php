<!DOCTYPE html>
<html>
<head>
    <title>trial</title>
    <link rel="stylesheet" href="abc.css">
</head>

<body>
    <div class="page_1">
        <!-- &larr; -->
        <a href="sid.htm" style="text-decoration:none;">Home</a>
        <h1>Welcome to Wallet</h1>
        <div class="con_1">
            <div class="get_info">
                <form action="money.php" id="form_1" method='post'>
                    <p>Add money to Wallet:</p>
                    <input type="number" placeholder="Enter Amount" name="wallet_money" id="wallet_money"><br>
                    <input type="submit" value="Add Money">
                </form><br>
                <form action="form.php" id="form_2" method='post'>
                    <p>Enter the Amount:</p>
                    <input type="number" placeholder="Enter Amount" name="amount" id="amount">
                    <p>Enter the Purpose:</p>
                    <input type="text" placeholder="Enter Purpose" name="purpose" id="purpose"><br>
                    <input type="submit" value="Add to Log">
                </form>
            </div>
            <div class="display_info">
                <p>Balance:</p>
                <p class="rupee"><?php include 'retrieve_data.php'?>&#8377</p>
            </div>
        </div>
    </div>
    <hr style="color:bisque;">
    <div class="page_2">
        <div class="log_container">
            <p class="log">Log:</p>
            <div class="sort_container">
                <p class="sort_by">Sort by Amount:</p>
                <form action="display1.php" method="post" class="sort">
                    <button class="btn" id="ascending">Ascending order</button>
                </form>
                <form action="display2.php" method="post" class="sort">
                    <button class="btn" id="descending">Descending order</button>
                </form>
            </div>
        </div>
        <div class="tables">
            <table>
                <tr>
                    <th><b>Sr.no</b></th>
                    <th><b>Amount</b></th>
                    <th><b>Purpose</b></th>
                    <th><b>Time Stamp</b></th>
                </tr>
                    <?php include 'display_table.php'?>
            </table>
        </div>
    </div>
</body>

</html>