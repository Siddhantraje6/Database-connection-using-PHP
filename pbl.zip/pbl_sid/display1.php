<!DOCTYPE html>
<html>
    <head>
        <title>Ascending order</title>
        <link rel="stylesheet" href="display.css">
    </head>
    <body>
        <div class="page1">
            <div class="nav_bar">
                <a href="sid.htm" style="text-decoration:none;">Home</a>
                <a href="abc.php" style="text-decoration:none;">Wallet</a>
            </div>
            <p class="log">Log in Ascending order :</p>
            <div class="tables">
                <table>
                    <tr>
                        <th><b>Sr.no</b></th>
                        <th><b>Amount</b></th>
                        <th><b>Purpose</b></th>
                        <th><b>Time Stamp</b></th>
                    </tr>
                        <?php include 'sort_ascending.php'?>
                </table>
            </div>
        </div>
    </body>
</html>