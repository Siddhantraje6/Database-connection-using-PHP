<?php
    $connection=mysqli_connect('localhost','root','','wallet');
    $get_request="SELECT * FROM `log_details`";
    $final_query=mysqli_query($connection,$get_request);
    $result;

    //sorting the amount based upon the value in the ascending order
    $array=array();
    $array_ascending=array();
    $i=0;
    $j=0;
    $k=0;
    $x=1;
    $index=0;
    $test_element=0;
    while($result=mysqli_fetch_assoc($final_query)){
        $array[$i]=$result['Amount'];
        $i++;
    }
    for($j=$i-1;$j>=0;$j--){
        for($k=0;$k<$i;$k++){
            if($array[$k]>$test_element){
                $test_element=$array[$k];
                $index=$k;
            }
            //this loop will give me the maximum amount
        }
        $array_ascending[$j]=$test_element;
        $test_element=0;
        $array[$index]=0;
        $index=0;
    }
    $amt_final;
    $result1;
    for($j=0;$j<$i;$j++){
        $amt_final=$array_ascending[$j];
        $get_request1="SELECT * FROM `log_details` WHERE `Amount`=$amt_final";
        $final_query1=mysqli_query($connection,$get_request1);
        $result1=mysqli_fetch_assoc($final_query1);
        echo '<tr>
        <td>'.$x.'</td>
        <td>'.$amt_final.'</td>
        <td>'.$result1['Purpose'].'</td>
        <td>'.$result1['Date_time'].'</td>
        </tr>';
        $x++;
    }
?>