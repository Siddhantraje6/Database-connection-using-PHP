<?php
    $connection=mysqli_connect('localhost','root','','wallet');
    $g_p="SELECT * FROM `final amount`";
    $query=mysqli_query($connection,$g_p);
    $rows=mysqli_num_rows($query);
    if($rows>0){
        $get_parameter="SELECT * FROM `final amount` ORDER BY `Id` DESC LIMIT 1";
        $result=mysqli_query($connection,$get_parameter);
        $final=mysqli_fetch_assoc($result);
        $value=$_POST['wallet_money']+$final['Amount_final'];
        $insert_parameter="INSERT INTO `final amount` (`Id`, `Amount_final`) VALUES (NULL, '$value')";
        $inset_query=mysqli_query($connection,$insert_parameter);
        header("Location: ../pbl_sid/abc.php");
    }
    else{
        $value=$_POST['wallet_money'];
        $insert_parameter="INSERT INTO `final amount` (`Id`, `Amount_final`) VALUES (NULL, '$value')";
        $inset_query=mysqli_query($connection,$insert_parameter);
        header("Location: ../pbl_sid/abc.php");
    }
?>