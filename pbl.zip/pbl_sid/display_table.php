<?php
    $connection=mysqli_connect('localhost','root','','wallet');
    $get_request="SELECT * FROM `log_details`";
    $final_query=mysqli_query($connection,$get_request);
    $result;
    $x=1;
    while($result=mysqli_fetch_assoc($final_query)){
        echo '<tr>
        <td>'.$x.'</td>
        <td>'.$result['Amount'].'</td>
        <td>'.$result['Purpose'].'</td>
        <td>'.$result['Date_time'].'</td>
    </tr>';
    $x++;
    }
?>